package com.webtranslator

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val RC_AUDIO = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(false)
                // Use Chrome's WebSpeech engine & allow mic
                userAgentString = userAgentString.replace("; wv", "") + " Mobile"
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    // Open external links in external browser, keep app pages inside
                    val url = request.url.toString()
                    if (url.startsWith("file:///android_asset/") || url.startsWith("file:///android_res/")) {
                        view.loadUrl(url)
                        return false
                    }
                    if (url.contains("mymemory.translated") || url.contains("speech") || url.contains("google")) {
                        view.loadUrl(url)
                        return false
                    }
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val res = request.resources ?: return
                    for (r in res) {
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) {
                                request.grant(arrayOf(r))
                                return
                            } else {
                                ActivityCompat.requestPermissions(this@MainActivity,
                                    arrayOf(Manifest.permission.RECORD_AUDIO), RC_AUDIO)
                                request.deny()
                                return
                            }
                        }
                    }
                    request.deny()
                }
            }
        }

        // Ask mic permission up front
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), RC_AUDIO)
        }

        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RC_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                webView.reload()
            } else {
                Toast.makeText(this, "اجازه میکروفون لازم است", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
